package com.example.myapplication.fragments2

import androidx.fragment.app.Fragment
import com.example.myapplication.R


class QuotesFragment : Fragment(R.layout.fragment_quotes) {

}